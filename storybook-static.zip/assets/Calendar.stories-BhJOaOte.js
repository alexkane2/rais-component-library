const r=`
  <style>
    /* ── Date cell: 37x41, padding T8 R8 B8 L8, radius 4 ── */
    .rais-date {
      width: 37px;
      height: 41px;
      display: flex;
      align-items: center;
      justify-content: center;
      border-radius: 4px;
      box-sizing: border-box;
      padding: 8px;
      cursor: pointer;
      flex-shrink: 0;
    }

    .rais-date__num {
      font-family: 'Figtree', sans-serif;
      font-size: 16px;
      font-weight: 500;
      line-height: 1;
    }

    /* Other Month: #8D9091, no bg */
    .rais-date--other-month .rais-date__num { color: #8D9091; }

    /* Unselected: #333333, no bg */
    .rais-date--unselected .rais-date__num { color: #333333; }

    /* Selected: #007CBD text, #EDF6FC bg */
    .rais-date--selected {
      background: #EDF6FC;
    }
    .rais-date--selected .rais-date__num { color: #007CBD; }

    /* Hover: #007CBD text, #DCDCDC border */
    .rais-date--hover {
      border: 1px solid #DCDCDC;
    }
    .rais-date--hover .rais-date__num { color: #007CBD; }
  </style>
`;function a(e,t="unselected"){return`
    <div class="rais-date rais-date--${t}">
      <span class="rais-date__num">${e}</span>
    </div>
  `}const n=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&display=swap');
    :root {
      --color-text-default: #454545;
      --color-border: #DCDCDC;
      --color-bg-calendar: #F3F3F3;
      --color-bg-white: #FFFFFF;
      --color-action: #007CBD;
      --font-family: 'Figtree', sans-serif;
    }

    .rais-calendar {
      width:299px; background:var(--color-bg-calendar);
      border:1px solid var(--color-border); border-radius:4px;
      padding:12px 0 0 0; display:flex; flex-direction:column;
      align-items:center; font-family:var(--font-family); box-sizing:border-box;
    }

    .rais-calendar__nav { display:flex; flex-direction:row; align-items:center; gap:12px; padding-bottom:12px; }

    /* Chevron: 24x24, tinted blue */
    .rais-calendar__chevron {
      width:24px; height:24px; display:flex; align-items:center;
      justify-content:center; cursor:pointer; flex-shrink:0;
    }
    .rais-calendar__chevron img {
      filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg);
    }

    /* Month/Year dropdowns: 90x40 */
    .rais-calendar__dropdown {
      width:90px; height:40px; padding:8px 16px;
      background:var(--color-bg-white); border:1px solid #CCCCCC;
      border-radius:4px; display:flex; flex-direction:row;
      align-items:center; justify-content:space-between;
      gap:8px; box-sizing:border-box;
    }
    .rais-calendar__dropdown-label { font-size:14px; color:var(--color-text-default); flex:1; }
    .rais-calendar__dropdown-caret { display:flex; align-items:center; }

    /* Days header: 299x36 */
    .rais-calendar__days-header {
      width:299px; display:flex; flex-direction:row; align-items:center;
      gap:4px; padding:4px 8px; background:var(--color-bg-calendar); box-sizing:border-box;
    }
    .rais-calendar__day-label {
      width:37px; height:28px; display:flex; align-items:center;
      justify-content:center; font-size:16px; color:var(--color-text-default); flex-shrink:0;
    }

    /* Dates grid */
    .rais-calendar__dates {
      width:299px; background:var(--color-bg-white);
      padding:12px 8px; display:flex; flex-direction:column;
      gap:4px; box-sizing:border-box;
    }
    .rais-calendar__week { display:flex; flex-direction:row; gap:4px; }
  </style>
`,x=["Mo","Tu","We","Th","Fr","Sa","Su"],h=[[[28,"other-month"],[29,"other-month"],[30,"other-month"],[31,"other-month"],[1,"unselected"],[2,"unselected"],[3,"unselected"]],[[4,"unselected"],[5,"unselected"],[6,"unselected"],[7,"unselected"],[8,"unselected"],[9,"unselected"],[10,"unselected"]],[[11,"unselected"],[12,"unselected"],[13,"unselected"],[14,"unselected"],[15,"selected"],[16,"unselected"],[17,"unselected"]],[[18,"unselected"],[19,"unselected"],[20,"unselected"],[21,"unselected"],[22,"unselected"],[23,"unselected"],[24,"unselected"]],[[25,"unselected"],[26,"unselected"],[27,"unselected"],[28,"unselected"],[1,"other-month"],[2,"other-month"],[3,"other-month"]]];function g({month:e,year:t,weeks:d}){const i=e??"Feb",l=t??"2024",o=d??h;return`
    ${n}
    ${r}
    <div class="rais-calendar">
      <div class="rais-calendar__nav">
        <span class="rais-calendar__chevron">
          <img src="assets/boxicons/bx-chevron-left.svg" width="20" height="20" alt="previous month" />
        </span>
        <div style="display:flex;gap:8px;">
          <div class="rais-calendar__dropdown">
            <span class="rais-calendar__dropdown-label">${i}</span>
            <span class="rais-calendar__dropdown-caret">
              <img src="assets/boxicons/bx-caret-down.svg" width="14" height="14" alt="caret" />
            </span>
          </div>
          <div class="rais-calendar__dropdown">
            <span class="rais-calendar__dropdown-label">${l}</span>
            <span class="rais-calendar__dropdown-caret">
              <img src="assets/boxicons/bx-caret-down.svg" width="14" height="14" alt="caret" />
            </span>
          </div>
        </div>
        <span class="rais-calendar__chevron">
          <img src="assets/boxicons/bx-chevron-right.svg" width="20" height="20" alt="next month" />
        </span>
      </div>
      <div class="rais-calendar__days-header">
        ${x.map(s=>`<span class="rais-calendar__day-label">${s}</span>`).join("")}
      </div>
      <div class="rais-calendar__dates">
        ${o.map(s=>`
          <div class="rais-calendar__week">
            ${s.map(([c,p])=>a(c,p)).join("")}
          </div>
        `).join("")}
      </div>
    </div>
  `}const u={title:"RAIS/Inputs/Fields/Calendar",tags:["autodocs"],argTypes:{month:{control:"text"},year:{control:"text"}},render:e=>g(e)},f={args:{month:"Feb",year:"2024"}},_={render:()=>`
    ${n}${r}
    <div style="display:flex;flex-direction:column;gap:16px;padding:24px;background:#F0F2F5;border-radius:8px;">
      <span style="font-family:'Figtree',sans-serif;font-size:12px;color:#8D9091;">Date cell states — .Dates component</span>
      <div style="display:flex;gap:8px;align-items:center;">
        ${a("28","other-month")}
        ${a("28","unselected")}
        ${a("28","selected")}
        ${a("28","hover")}
      </div>
      <div style="display:flex;gap:8px;font-family:'Figtree',sans-serif;font-size:11px;color:#8D9091;">
        <span style="width:37px;text-align:center;">Other month</span>
        <span style="width:37px;text-align:center;">Unselected</span>
        <span style="width:37px;text-align:center;">Selected</span>
        <span style="width:37px;text-align:center;">Hover</span>
      </div>
    </div>
  `},b=["Default","DateCellStates"];export{_ as DateCellStates,f as Default,b as __namedExportsOrder,u as default};
