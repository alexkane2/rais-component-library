const t={"gray-blue":{text:"#293B52",bg:"#E1EAF4"},periwinkle:{text:"#1E4D66",bg:"#E3F5FF"},teal:{text:"#15545A",bg:"#D8F6F8"},"forest-green":{text:"#084F47",bg:"#DEFAEB"},"pea-green":{text:"#254909",bg:"#E7F5E1"},yellow:{text:"#6F590D",bg:"#FFF8DC"},orange:{text:"#893C08",bg:"#FFEFE4"},pink:{text:"#751336",bg:"#FBE8E9"},magenta:{text:"#54143F",bg:"#EFE3EB"},"warm-gray":{text:"#3B3434",bg:"#F4EFEF"},"standard-blue":{text:"#004288",bg:"#EDF6FC"},"standard-gray":{text:"#454545",bg:"#F3F3F3"}},h={"gray-blue":"Gray Blue",periwinkle:"Periwinkle",teal:"Teal","forest-green":"Forest Green","pea-green":"Pea Green",yellow:"Yellow",orange:"Orange",pink:"Pink",magenta:"Magenta","warm-gray":"Warm Gray","standard-blue":"Standard Blue","standard-gray":"Standard Gray"},F={small:{padding:"4px 8px",gap:"4px",fontSize:"10px",iconSize:10},medium:{padding:"4px 12px",gap:"4px",fontSize:"12px",iconSize:12},large:{padding:"6px 16px",gap:"8px",fontSize:"13px",iconSize:14}},S=["","bxs-inbox","bxs-tag","bxs-bookmark","bxs-star","bxs-flag","bxs-check-circle","bxs-error-circle","bxs-info-circle","bxs-time","bxs-bell","bxs-folder","bxs-category","bx-check","bx-x"],n=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@600&display=swap');

    /* Tokens — names match Figma variables */
    :root {
      --border-radius-xl: 16px;
      --spacing-01: 4px;
      --spacing-03: 8px;
      --font-family: 'Figtree', sans-serif;
    }

    .rais-chip {
      display: inline-flex;
      align-items: center;
      border-radius: var(--border-radius-xl);
      font-family: var(--font-family);
      font-weight: 600;
      line-height: 1.2;
      white-space: nowrap;
      box-sizing: border-box;
    }

    .rais-chip__icon {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    /* Icon tinting — applied per-color via CSS filter computed from text color */
    .rais-chip__icon img {
      width: 100%;
      height: 100%;
    }
  </style>
`,z={"gray-blue":"invert(21%) sepia(15%) saturate(1200%) hue-rotate(180deg)",periwinkle:"invert(28%) sepia(20%) saturate(1000%) hue-rotate(170deg)",teal:"invert(28%) sepia(60%) saturate(800%) hue-rotate(140deg)","forest-green":"invert(25%) sepia(80%) saturate(700%) hue-rotate(130deg)","pea-green":"invert(20%) sepia(60%) saturate(900%) hue-rotate(60deg)",yellow:"invert(35%) sepia(60%) saturate(900%) hue-rotate(15deg)",orange:"invert(25%) sepia(80%) saturate(2000%) hue-rotate(0deg)",pink:"invert(15%) sepia(50%) saturate(2500%) hue-rotate(310deg)",magenta:"invert(13%) sepia(60%) saturate(2000%) hue-rotate(280deg)","warm-gray":"invert(20%) sepia(5%) saturate(300%) hue-rotate(0deg)","standard-blue":"invert(20%) sepia(80%) saturate(1500%) hue-rotate(195deg)","standard-gray":"invert(25%) sepia(0%) saturate(0%) hue-rotate(0deg)"};function a({label:e,color:s,size:l,icon:c}){const o=s??"gray-blue",b=l??"medium",g=e??"Label",i=c??"bxs-inbox",{text:d,bg:x}=t[o],{padding:p,gap:m,fontSize:u,iconSize:r}=F[b],y=z[o],f=i?`
    <span class="rais-chip__icon" style="width:${r}px;height:${r}px;filter:${y};">
      <img src="assets/boxicons/${i}.svg" alt="${i}" />
    </span>
  `:"";return`
    ${n}
    <span class="rais-chip" style="
      background: ${x};
      color: ${d};
      padding: ${p};
      gap: ${m};
      font-size: ${u};
    ">
      ${f}
      <span>${g}</span>
    </span>
  `}const L={title:"RAIS/Labeling/Colorful Label Chips",tags:["autodocs"],argTypes:{label:{control:"text",description:"Chip label text"},color:{control:"select",options:Object.keys(t),description:"12 color options — each uses the -600 token for text/icon and the -100 token for background"},size:{control:"select",options:["small","medium","large"],description:"small=10px SemiBold | medium=12px SemiBold | large=13px SemiBold"},icon:{control:"select",options:S,description:"Boxicons SVG name from assets/boxicons/ — defaults to bxs-inbox, empty for no icon"}},render:e=>a(e)},k={args:{label:"Label",color:"gray-blue",size:"small",icon:"bxs-inbox"}},w={args:{label:"Label",color:"gray-blue",size:"medium",icon:"bxs-inbox"}},E={args:{label:"Label",color:"gray-blue",size:"large",icon:"bxs-inbox"}},v={args:{label:"Label",color:"periwinkle",size:"medium",icon:"bxs-inbox"}},$={args:{label:"Label",color:"teal",size:"medium",icon:"bxs-inbox"}},O={args:{label:"Label",color:"forest-green",size:"medium",icon:"bxs-inbox"}},B={args:{label:"Label",color:"pea-green",size:"medium",icon:"bxs-inbox"}},C={args:{label:"Label",color:"yellow",size:"medium",icon:"bxs-inbox"}},G={args:{label:"Label",color:"orange",size:"medium",icon:"bxs-inbox"}},_={args:{label:"Label",color:"pink",size:"medium",icon:"bxs-inbox"}},P={args:{label:"Label",color:"magenta",size:"medium",icon:"bxs-inbox"}},A={args:{label:"Label",color:"warm-gray",size:"medium",icon:"bxs-inbox"}},I={args:{label:"Label",color:"standard-blue",size:"medium",icon:"bxs-inbox"}},T={args:{label:"Label",color:"standard-gray",size:"medium",icon:"bxs-inbox"}},D={args:{label:"Label",color:"gray-blue",size:"medium",icon:""}},M={render:()=>`
    ${n}
    <div style="display:flex;flex-direction:column;gap:24px;padding:24px;background:#F0F2F5;border-radius:8px;font-family:'Figtree',sans-serif;">
      ${Object.keys(t).map(e=>`
        <div style="display:flex;flex-direction:column;gap:8px;">
          <span style="font-size:11px;color:#8D9091;">${h[e].toUpperCase()}</span>
          <div style="display:flex;gap:16px;align-items:center;">
            ${a({label:"Label",color:e,size:"small",icon:"bxs-inbox"})}
            ${a({label:"Label",color:e,size:"medium",icon:"bxs-inbox"})}
            ${a({label:"Label",color:e,size:"large",icon:"bxs-inbox"})}
          </div>
        </div>
      `).join("")}
    </div>
  `},R=["Small","Medium","Large","Periwinkle","Teal","ForestGreen","PeaGreen","Yellow","Orange","Pink","Magenta","WarmGray","StandardBlue","StandardGray","NoIcon","AllVariants"];export{M as AllVariants,O as ForestGreen,E as Large,P as Magenta,w as Medium,D as NoIcon,G as Orange,B as PeaGreen,v as Periwinkle,_ as Pink,k as Small,I as StandardBlue,T as StandardGray,$ as Teal,A as WarmGray,C as Yellow,R as __namedExportsOrder,L as default};
