const o=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;600&display=swap');
    :root {
      --color-label: #4D586A;
      --color-placeholder: #8D9091;
      --color-text: #4D586A;
      --color-border-default: #CCCCCC;
      --color-border-focus: #007CBD;
      --font-family: 'Figtree', sans-serif;
      --border-radius-sm: 4px;
    }

    .rais-searchbar { display:flex; flex-direction:column; gap:4px; width:350px; font-family:var(--font-family); }
    .rais-searchbar__labels { display:flex; flex-direction:column; gap:2px; }
    .rais-searchbar__label { font-size:14px; font-weight:600; color:var(--color-label); }
    .rais-searchbar__instructions { font-size:12px; color:var(--color-label); }

    .rais-searchbar__box {
      display:flex; align-items:center; justify-content:space-between;
      height:40px; padding:8px 12px;
      background:#FFFFFF;
      border:1px solid var(--color-border-default);
      border-radius:var(--border-radius-sm);
      box-sizing:border-box; gap:8px;
    }
    .rais-searchbar__box--focus { border-color:var(--color-border-focus); }

    .rais-searchbar__input-container { display:flex; align-items:center; gap:4px; flex:1; min-width:0; }
    .rais-searchbar__input { flex:1; border:none; outline:none; font-family:var(--font-family); font-size:14px; color:var(--color-text); background:transparent; min-width:0; }
    .rais-searchbar__input::placeholder { color:var(--color-placeholder); }
    .rais-searchbar__cursor { font-size:14px; color:var(--color-placeholder); }

    /* Icon: 16x16, bx-search.svg */
    .rais-searchbar__icon { width:16px; height:16px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }
  </style>
`;function a({label:e,instructions:i,state:s}){const t=s==="mouse-enter",l=s==="entered",n=["rais-searchbar__box",t?"rais-searchbar__box--focus":""].filter(Boolean).join(" ");let r="";return t?r='<span class="rais-searchbar__cursor">|</span>':l?r='<input class="rais-searchbar__input" type="text" value="Text" />':r='<input class="rais-searchbar__input" type="text" placeholder="Search..." />',`
    ${o}
    <div class="rais-searchbar">
      <div class="rais-searchbar__labels">
        ${e!==!1?`<span class="rais-searchbar__label">${e??"Label"}</span>`:""}
        ${i!==!1?'<span class="rais-searchbar__instructions">More instructions here.</span>':""}
      </div>
      <div class="${n}">
        <div class="rais-searchbar__input-container">${r}</div>
        <div class="rais-searchbar__icon">
          <img src="assets/boxicons/bx-search.svg" width="16" height="16" alt="search" />
        </div>
      </div>
    </div>
  `}const c={title:"RAIS/Inputs/Fields/Search Bar",tags:["autodocs"],argTypes:{label:{control:"text"},instructions:{control:"boolean"},state:{control:"select",options:["empty","entered","mouse-enter"]}},render:e=>a(e)},d={args:{label:"Label",state:"empty",instructions:!0}},b={args:{label:"Label",state:"entered",instructions:!0}},p={args:{label:"Label",state:"mouse-enter",instructions:!0}},u={args:{label:!1,state:"empty",instructions:!1}},x={render:()=>`
    ${o}
    <div style="display:flex;flex-direction:column;gap:24px;padding:24px;background:#F0F2F5;border-radius:8px;">
      ${a({label:"Label",state:"empty",instructions:!0})}
      ${a({label:"Label",state:"entered",instructions:!0})}
      ${a({label:"Label",state:"mouse-enter",instructions:!0})}
    </div>
  `},h=["Empty","Entered","MouseEnter","NoLabel","AllVariants"];export{x as AllVariants,d as Empty,b as Entered,p as MouseEnter,u as NoLabel,h as __namedExportsOrder,c as default};
