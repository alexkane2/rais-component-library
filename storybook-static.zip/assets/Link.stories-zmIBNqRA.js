const r=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;600;700&display=swap');
    :root {
      --link-blue-default:  #007CBD;
      --link-blue-hover:    #178FCF;
      --link-black-default: #101928;
      --link-black-hover:   #8D9091;
      --link-gray-default:  #8D9091;
      --link-gray-hover:    #4D586A;
      --font-family: 'Figtree', sans-serif;
    }

    .rais-link { display:inline-flex; align-items:center; text-decoration:none; cursor:pointer; font-family:var(--font-family); }

    .rais-link--large  { gap:6px; font-size:16px; font-weight:700; }
    .rais-link--medium { gap:4px; font-size:14px; font-weight:700; }
    .rais-link--small  { gap:4px; font-size:13px; font-weight:600; }

    .rais-link--blue  { color:var(--link-blue-default); }
    .rais-link--black { color:var(--link-black-default); }
    .rais-link--gray  { color:var(--link-gray-default); }

    .rais-link--blue.rais-link--hover  { color:var(--link-blue-hover); }
    .rais-link--black.rais-link--hover { color:var(--link-black-hover); }
    .rais-link--gray.rais-link--hover  { color:var(--link-gray-hover); }

    .rais-link__icon { display:flex; align-items:center; justify-content:center; flex-shrink:0; }
    .rais-link--large  .rais-link__icon img { width:16px; height:16px; }
    .rais-link--medium .rais-link__icon img { width:14px; height:14px; }
    .rais-link--small  .rais-link__icon img { width:13px; height:13px; }

    /* Icon color filters per color+state */
    .rais-link--blue  .rais-link__icon img { filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg); }
    .rais-link--blue.rais-link--hover .rais-link__icon img { filter: invert(52%) sepia(60%) saturate(400%) hue-rotate(170deg); }
    .rais-link--black .rais-link__icon img { filter: brightness(0) saturate(100%) invert(8%) sepia(18%) saturate(1200%) hue-rotate(180deg); }
    .rais-link--black.rais-link--hover .rais-link__icon img { filter: invert(60%) sepia(5%) saturate(200%) hue-rotate(169deg); }
    .rais-link--gray  .rais-link__icon img { filter: invert(60%) sepia(5%) saturate(200%) hue-rotate(169deg); }
    .rais-link--gray.rais-link--hover .rais-link__icon img { filter: invert(30%) sepia(10%) saturate(800%) hue-rotate(180deg); }
  </style>
`,m=["bxs-plus-circle","bx-external-link","bx-right-arrow-alt","bx-left-arrow-alt","bx-link-external","bx-download","bx-upload","bx-edit","bx-check","bx-info-circle","bxs-check-circle","bxs-info-circle"];function e({label:i,size:o,color:n,state:s,iconLeft:c,iconRight:u,href:f,icon:g}){const d=o??"medium",b=n??"blue",l=s??"default",p=i??"Label",t=g??"bxs-plus-circle",k=["rais-link",`rais-link--${d}`,`rais-link--${b}`,l==="hover"?"rais-link--hover":""].filter(Boolean).join(" "),a=`<span class="rais-link__icon"><img src="assets/boxicons/${t}.svg" alt="${t}" /></span>`;return`
    ${r}
    <a class="${k}" href="${f??"#"}" ${l==="hover"?'style="pointer-events:none;"':""}>
      ${c!==!1?a:""}
      <span>${p}</span>
      ${u!==!1?a:""}
    </a>
  `}const x={title:"RAIS/Actions/Link",tags:["autodocs"],argTypes:{label:{control:"text"},href:{control:"text"},icon:{control:"select",options:m,description:'Boxicons SVG from public/assets/boxicons/ — Angular: <img src="assets/boxicons/[name].svg" />'},size:{control:"select",options:["large","medium","small"]},color:{control:"select",options:["blue","black","gray"]},state:{control:"select",options:["default","hover"]},iconLeft:{control:"boolean"},iconRight:{control:"boolean"}},render:i=>e(i)},h={args:{label:"Label",size:"medium",color:"blue",state:"default",iconLeft:!0,iconRight:!0}},v={args:{label:"Label",size:"medium",color:"blue",state:"hover",iconLeft:!0,iconRight:!0}},y={args:{label:"Label",size:"medium",color:"black",state:"default",iconLeft:!0,iconRight:!0}},L={args:{label:"Label",size:"medium",color:"black",state:"hover",iconLeft:!0,iconRight:!0}},_={args:{label:"Label",size:"medium",color:"gray",state:"default",iconLeft:!0,iconRight:!0}},z={args:{label:"Label",size:"medium",color:"gray",state:"hover",iconLeft:!0,iconRight:!0}},R={args:{label:"Label",size:"large",color:"blue",state:"default",iconLeft:!0,iconRight:!0}},$={args:{label:"Label",size:"small",color:"blue",state:"default",iconLeft:!0,iconRight:!0}},w={args:{label:"Label",size:"medium",color:"blue",state:"default",iconLeft:!1,iconRight:!1}},D={args:{label:"Open in new tab",size:"medium",color:"blue",state:"default",icon:"bx-external-link",iconLeft:!1,iconRight:!0}},B={render:()=>`
    ${r}
    <div style="display:flex;flex-direction:column;gap:24px;padding:24px;background:#F0F2F5;border-radius:8px;font-family:'Figtree',sans-serif;">
      <div style="display:flex;flex-direction:column;gap:8px;">
        <span style="font-size:11px;color:#8D9091;">BLUE</span>
        <div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;">
          ${e({label:"Default",size:"medium",color:"blue",state:"default",iconLeft:!0,iconRight:!0})}
          ${e({label:"Hover",size:"medium",color:"blue",state:"hover",iconLeft:!0,iconRight:!0})}
          ${e({label:"Large",size:"large",color:"blue",state:"default",iconLeft:!0,iconRight:!0})}
          ${e({label:"Small",size:"small",color:"blue",state:"default",iconLeft:!0,iconRight:!0})}
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <span style="font-size:11px;color:#8D9091;">BLACK</span>
        <div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;">
          ${e({label:"Default",size:"medium",color:"black",state:"default",iconLeft:!0,iconRight:!0})}
          ${e({label:"Hover",size:"medium",color:"black",state:"hover",iconLeft:!0,iconRight:!0})}
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <span style="font-size:11px;color:#8D9091;">GRAY</span>
        <div style="display:flex;gap:24px;align-items:center;flex-wrap:wrap;">
          ${e({label:"Default",size:"medium",color:"gray",state:"default",iconLeft:!0,iconRight:!0})}
          ${e({label:"Hover",size:"medium",color:"gray",state:"hover",iconLeft:!0,iconRight:!0})}
        </div>
      </div>
    </div>
  `},A=["BlueDefault","BlueHover","BlackDefault","BlackHover","GrayDefault","GrayHover","Large","Small","TextOnly","ExternalLink","AllVariants"];export{B as AllVariants,y as BlackDefault,L as BlackHover,h as BlueDefault,v as BlueHover,D as ExternalLink,_ as GrayDefault,z as GrayHover,R as Large,$ as Small,w as TextOnly,A as __namedExportsOrder,x as default};
