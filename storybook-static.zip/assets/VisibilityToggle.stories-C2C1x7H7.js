const i=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@600&display=swap');
    :root {
      --color-text: #333333;
      --color-border: #CCCCCC;
      --color-bg-default: #FFFFFF;
      --color-bg-hover: #EDF6FC;
      --color-icon: #333333;
      --font-family: 'Figtree', sans-serif;
    }

    /* ── Visibility Toggle ──
       Pill shape, 26px height
    ── */
    .rais-vis-toggle {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 6px 12px;
      height: 26px;
      background: var(--color-bg-default);
      border: 1px solid var(--color-border);
      border-radius: 12px;
      box-sizing: border-box;
      cursor: pointer;
      font-family: var(--font-family);
    }

    .rais-vis-toggle--hover {
      background: var(--color-bg-hover);
    }

    /* Icon: 14×14 */
    .rais-vis-toggle__icon {
      width: 14px;
      height: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    /* Label: 12px SemiBold #333333 */
    .rais-vis-toggle__label {
      font-size: 12px;
      font-weight: 600;
      color: var(--color-text);
      line-height: 1;
      white-space: nowrap;
    }
  </style>
`;function e({label:t,toggleState:l,interaction:a}){const s=a==="hover",o=l==="hide"?"bxs-hide":"bxs-show";return`
    ${i}
    <button class="rais-vis-toggle ${s?"rais-vis-toggle--hover":""}">
      <span class="rais-vis-toggle__icon">
        <img src="assets/boxicons/${o}.svg" width="14" height="14" alt="${o}" />
      </span>
      <span class="rais-vis-toggle__label">${t??"Label"}</span>
    </button>
  `}const n={title:"RAIS/Filters/Visibility Toggle",tags:["autodocs"],argTypes:{label:{control:"text",description:"Button label text"},toggleState:{control:"select",options:["show","hide"],description:"show → bxs-show.svg (eye open) | hide → bxs-hide.svg (eye closed)"},interaction:{control:"select",options:["default","hover"],description:"default=white bg | hover=#EDF6FC bg"}},render:t=>e(t)},g={name:"Show — Default",args:{label:"Label",toggleState:"show",interaction:"default"}},d={name:"Show — Hover",args:{label:"Label",toggleState:"show",interaction:"hover"}},c={name:"Hide — Default",args:{label:"Label",toggleState:"hide",interaction:"default"}},p={name:"Hide — Hover",args:{label:"Label",toggleState:"hide",interaction:"hover"}},h={render:()=>`
    ${i}
    <div style="display:flex;flex-direction:column;gap:16px;padding:24px;background:#F0F2F5;border-radius:8px;">
      <div style="display:flex;flex-direction:column;gap:8px;">
        <span style="font-family:'Figtree',sans-serif;font-size:11px;color:#8D9091;">SHOW STATE</span>
        <div style="display:flex;gap:12px;align-items:center;">
          ${e({label:"Label",toggleState:"show",interaction:"default"})}
          ${e({label:"Label",toggleState:"show",interaction:"hover"})}
        </div>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        <span style="font-family:'Figtree',sans-serif;font-size:11px;color:#8D9091;">HIDE STATE</span>
        <div style="display:flex;gap:12px;align-items:center;">
          ${e({label:"Label",toggleState:"hide",interaction:"default"})}
          ${e({label:"Label",toggleState:"hide",interaction:"hover"})}
        </div>
      </div>
    </div>
  `},b=["ShowDefault","ShowHover","HideDefault","HideHover","AllVariants"];export{h as AllVariants,c as HideDefault,p as HideHover,g as ShowDefault,d as ShowHover,b as __namedExportsOrder,n as default};
