const l=`
  <style>
    :root {
      --color-chip-bg: #EDF6FC;
      --color-chip-border: #007CBD;
      --color-chip-text: #4D586A;
      --font-family: 'Figtree', sans-serif;
    }

    /* Squared: padding T4 R6 B4 L8, gap 4px, radius 4px */
    .rais-sel-label--squared {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 6px 4px 8px;
      background: var(--color-chip-bg);
      border: 1px solid var(--color-chip-border);
      border-radius: 4px;
      font-family: var(--font-family);
      font-size: 12px; font-weight: 500;
      color: var(--color-chip-text);
      white-space: nowrap;
    }

    /* Rounded: padding T4 R8 B4 L10, gap 4px, radius 16px */
    .rais-sel-label--rounded {
      display: inline-flex; align-items: center; gap: 4px;
      padding: 4px 8px 4px 10px;
      background: var(--color-chip-bg);
      border: 1px solid var(--color-chip-border);
      border-radius: 16px;
      font-family: var(--font-family);
      font-size: 12px; font-weight: 500;
      color: var(--color-chip-text);
      white-space: nowrap;
    }

    /* Dismiss icon: 14x14 frame, 8x8 SVG */
    .rais-sel-label__icon {
      width: 14px; height: 14px;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0; cursor: pointer;
    }

    /* Tint the dismiss icon to match chip border color */
    .rais-sel-label__icon img {
      filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg);
    }
  </style>
`;function b({label:r,style:a}){return`
    ${l}
    <span class="rais-sel-label--squared">
      ${r??"Label"}
      <span class="rais-sel-label__icon">
        <img src="assets/boxicons/bx-x.svg" width="8" height="8" alt="dismiss" />
      </span>
    </span>
  `}const u=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600&display=swap');
    :root {
      --color-label: #4D586A;
      --color-optional: #8D9091;
      --color-placeholder: #CCCCCC;
      --color-text: #4D586A;
      --color-cursor: #8D9091;
      --color-error: #CA222D;
      --color-divider: #EFEFEF;
      --color-border-default: #CCCCCC;
      --color-border-focus: #007CBD;
      --color-border-error: #CA222D;
      --color-bg-white: #FFFFFF;
      --font-family: 'Figtree', sans-serif;
      --border-radius-sm: 4px;
    }

    .rais-multi { display:flex; flex-direction:column; gap:4px; width:350px; font-family:var(--font-family); }
    .rais-multi__labels { display:flex; flex-direction:column; gap:2px; }
    .rais-multi__label-row { display:flex; align-items:center; gap:12px; }
    .rais-multi__label { font-size:14px; font-weight:600; color:var(--color-label); }
    .rais-multi__optional { font-size:14px; color:var(--color-optional); }
    .rais-multi__instructions { font-size:12px; color:var(--color-label); }

    .rais-multi__field {
      display:flex; align-items:center; justify-content:space-between;
      height:40px; padding:8px 12px;
      background:var(--color-bg-white);
      border:1px solid var(--color-border-default);
      border-radius:var(--border-radius-sm);
      box-sizing:border-box; gap:8px;
    }
    .rais-multi__field--focus { border-color:var(--color-border-focus); }
    .rais-multi__field--error { border-color:var(--color-border-error); }

    .rais-multi__inner { display:flex; align-items:center; gap:4px; flex:1; min-width:0; overflow:hidden; }
    .rais-multi__input { flex:1; border:none; outline:none; font-family:var(--font-family); font-size:14px; color:var(--color-text); background:transparent; min-width:0; }
    .rais-multi__input::placeholder { color:var(--color-placeholder); }
    .rais-multi__cursor { font-size:14px; color:var(--color-cursor); }
    .rais-multi__count  { font-size:14px; color:var(--color-text); }

    .rais-multi__icon-divider  { display:flex; align-items:center; gap:10px; flex-shrink:0; }
    .rais-multi__icons-divider { display:flex; align-items:center; gap:10px; flex-shrink:0; }
    .rais-multi__divider { width:1px; height:24px; background:var(--color-divider); flex-shrink:0; }

    .rais-multi__clear { width:14px; height:14px; display:flex; align-items:center; justify-content:center; flex-shrink:0; cursor:pointer; }
    .rais-multi__caret { width:16px; height:16px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }

    /* Tint caret blue when focused/open */
    .rais-multi__caret--up img {
      filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg);
    }

    .rais-multi__error { font-size:12px; color:var(--color-error); }
  </style>
`,g=["Label","Label","Label"];function e({label:r,optional:a,instructions:o,state:s}){const t=s==="mouse-enter",n=s==="selection",x=s==="max-selected",c=s==="error",m=["rais-multi__field",t?"rais-multi__field--focus":"",c?"rais-multi__field--error":""].filter(Boolean).join(" ");let i="";n?i=`<div class="rais-multi__inner">${g.map(f=>b({label:f,style:"squared"})).join("")}</div>`:x?i='<div class="rais-multi__inner"><span class="rais-multi__count">3 items selected</span></div>':t?i='<div class="rais-multi__inner"><span class="rais-multi__cursor">|</span></div>':i='<div class="rais-multi__inner"><input class="rais-multi__input" type="text" placeholder="Search..." /></div>';const d=t?"bx-caret-up":"bx-caret-down",p=t?"rais-multi__caret rais-multi__caret--up":"rais-multi__caret",_=n?`<div class="rais-multi__icons-divider">
        <span class="rais-multi__clear"><img src="assets/boxicons/bx-x.svg" width="14" height="14" alt="clear" /></span>
        <div class="rais-multi__divider"></div>
        <span class="${p}"><img src="assets/boxicons/${d}.svg" width="16" height="16" alt="caret" /></span>
      </div>`:`<div class="rais-multi__icon-divider">
        <div class="rais-multi__divider"></div>
        <span class="${p}"><img src="assets/boxicons/${d}.svg" width="16" height="16" alt="caret" /></span>
      </div>`;return`
    ${u}
    ${l}
    <div class="rais-multi">
      <div class="rais-multi__labels">
        <div class="rais-multi__label-row">
          <span class="rais-multi__label">${r??"Label"}</span>
          ${a?'<span class="rais-multi__optional">(Optional)</span>':""}
        </div>
        ${o!==!1?'<span class="rais-multi__instructions">More instructions here.</span>':""}
      </div>
      <div class="${m}">
        ${i}
        ${_}
      </div>
      ${c?'<span class="rais-multi__error">Error message.</span>':""}
    </div>
  `}const h={title:"RAIS/Inputs/Dropdowns/Dropdown - Multiselect",tags:["autodocs"],argTypes:{label:{control:"text"},optional:{control:"boolean"},instructions:{control:"boolean"},state:{control:"select",options:["default","mouse-enter","selection","max-selected","error"]}},render:r=>e(r)},v={args:{label:"Label",state:"default",instructions:!0}},y={args:{label:"Label",state:"mouse-enter",instructions:!0}},w={args:{label:"Label",state:"selection",instructions:!0}},$={args:{label:"Label",state:"max-selected",instructions:!0}},C={args:{label:"Label",state:"error",instructions:!0}},L={args:{label:"Label",optional:!0,state:"default",instructions:!0}},E={render:()=>`
    ${u}${l}
    <div style="display:flex;flex-direction:column;gap:32px;padding:24px;background:#F0F2F5;border-radius:8px;">
      ${e({label:"Default",state:"default",instructions:!0})}
      ${e({label:"Mouse Enter",state:"mouse-enter",instructions:!0})}
      ${e({label:"Selection",state:"selection",instructions:!0})}
      ${e({label:"Max Selected",state:"max-selected",instructions:!0})}
      ${e({label:"Error",state:"error",instructions:!0})}
    </div>
  `},S=["Default","MouseEnter","Selection","MaxSelected","Error","Optional","AllVariants"];export{E as AllVariants,v as Default,C as Error,$ as MaxSelected,y as MouseEnter,L as Optional,w as Selection,S as __namedExportsOrder,h as default};
