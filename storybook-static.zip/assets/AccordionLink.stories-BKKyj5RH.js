const r=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;600;700&display=swap');
    :root {
      --accordion-default: #007CBD;
      --accordion-hover:   #178FCF;
      --font-family: 'Figtree', sans-serif;
    }

    .rais-accordion-link {
      display: inline-flex;
      align-items: center;
      cursor: pointer;
      text-decoration: none;
      font-family: var(--font-family);
    }

    /* Sizes */
    .rais-accordion-link--large  { gap: 8px; font-size: 16px; font-weight: 700; }
    .rais-accordion-link--medium { gap: 8px; font-size: 14px; font-weight: 700; }
    .rais-accordion-link--small  { gap: 6px; font-size: 13px; font-weight: 600; }

    /* States */
    .rais-accordion-link--default { color: var(--accordion-default); }
    .rais-accordion-link--hover   { color: var(--accordion-hover); }

    /* Icon container */
    .rais-accordion-link__icon {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    /* Icon sizes per component size — Caret style */
    .rais-accordion-link--large  .rais-accordion-link__icon--caret { width: 20px; height: 20px; }
    .rais-accordion-link--medium .rais-accordion-link__icon--caret { width: 18px; height: 18px; }
    .rais-accordion-link--small  .rais-accordion-link__icon--caret { width: 16px; height: 16px; }

    /* Icon sizes per component size — Plus style */
    .rais-accordion-link--large  .rais-accordion-link__icon--plus { width: 18px; height: 18px; }
    .rais-accordion-link--medium .rais-accordion-link__icon--plus { width: 16px; height: 16px; }
    .rais-accordion-link--small  .rais-accordion-link__icon--plus { width: 14px; height: 14px; }

    /* Tint icon to match text color */
    .rais-accordion-link--default .rais-accordion-link__icon img {
      filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg);
    }
    .rais-accordion-link--hover .rais-accordion-link__icon img {
      filter: invert(52%) sepia(60%) saturate(400%) hue-rotate(170deg);
    }
  </style>
`,v={caret:{closed:"bxs-chevron-down",open:"bxs-chevron-up"},plus:{closed:"bxs-plus-circle",open:"bx-minus"}},h={caret:{large:20,medium:18,small:16},plus:{large:18,medium:16,small:14}};function e({label:s,style:c,size:p,state:d,open:u}){const a=p??"medium",m=d??"default",l=c??"caret",f=u??!1,t=s??"Label",i=v[l][f?"open":"closed"],o=h[l][a],g=`rais-accordion-link__icon rais-accordion-link__icon--${l}`,y=["rais-accordion-link",`rais-accordion-link--${a}`,`rais-accordion-link--${m}`].join(" "),n=`<span class="${g}"><img src="assets/boxicons/${i}.svg" width="${o}" height="${o}" alt="${i}" /></span>`,x=l==="caret"?`<span>${t}</span>${n}`:`${n}<span>${t}</span>`;return`
    ${r}
    <a class="${y}">
      ${x}
    </a>
  `}const b={title:"RAIS/Actions/Accordion Link",tags:["autodocs"],argTypes:{label:{control:"text",description:"Link label text"},style:{control:"select",options:["caret","plus"],description:"caret=chevron icon on the right | plus=plus/minus icon on the left"},size:{control:"select",options:["large","medium","small"],description:"large=16px Bold | medium=14px Bold | small=13px SemiBold"},state:{control:"select",options:["default","hover"],description:"default=#007CBD | hover=#178FCF"},open:{control:"boolean",description:"false=collapsed (chevron-down / plus-circle) | true=expanded (chevron-up / minus)"}},render:s=>e(s)},z={name:"Caret — Closed",args:{label:"Label",style:"caret",size:"medium",state:"default",open:!1}},C={name:"Caret — Open",args:{label:"Label",style:"caret",size:"medium",state:"default",open:!0}},k={name:"Caret — Closed Hover",args:{label:"Label",style:"caret",size:"medium",state:"hover",open:!1}},$={name:"Caret — Open Hover",args:{label:"Label",style:"caret",size:"medium",state:"hover",open:!0}},L={name:"Plus — Closed",args:{label:"Label",style:"plus",size:"medium",state:"default",open:!1}},_={name:"Plus — Open",args:{label:"Label",style:"plus",size:"medium",state:"default",open:!0}},S={name:"Plus — Closed Hover",args:{label:"Label",style:"plus",size:"medium",state:"hover",open:!1}},O={name:"Plus — Open Hover",args:{label:"Label",style:"plus",size:"medium",state:"hover",open:!0}},P={args:{label:"Label",style:"caret",size:"large",state:"default",open:!1}},D={args:{label:"Label",style:"caret",size:"small",state:"default",open:!1}},w={render:()=>`
    ${r}
    <div style="display:flex;flex-direction:column;gap:32px;padding:24px;background:#F0F2F5;border-radius:8px;font-family:'Figtree',sans-serif;">

      <div style="display:flex;flex-direction:column;gap:12px;">
        <span style="font-size:11px;color:#8D9091;">CARET STYLE — Closed</span>
        <div style="display:flex;gap:24px;align-items:center;">
          ${e({label:"Large",style:"caret",size:"large",state:"default",open:!1})}
          ${e({label:"Medium",style:"caret",size:"medium",state:"default",open:!1})}
          ${e({label:"Small",style:"caret",size:"small",state:"default",open:!1})}
        </div>
        <span style="font-size:11px;color:#8D9091;">CARET STYLE — Open</span>
        <div style="display:flex;gap:24px;align-items:center;">
          ${e({label:"Large",style:"caret",size:"large",state:"default",open:!0})}
          ${e({label:"Medium",style:"caret",size:"medium",state:"default",open:!0})}
          ${e({label:"Small",style:"caret",size:"small",state:"default",open:!0})}
        </div>
        <span style="font-size:11px;color:#8D9091;">CARET STYLE — Hover</span>
        <div style="display:flex;gap:24px;align-items:center;">
          ${e({label:"Closed",style:"caret",size:"medium",state:"hover",open:!1})}
          ${e({label:"Open",style:"caret",size:"medium",state:"hover",open:!0})}
        </div>
      </div>

      <div style="display:flex;flex-direction:column;gap:12px;">
        <span style="font-size:11px;color:#8D9091;">PLUS STYLE — Closed</span>
        <div style="display:flex;gap:24px;align-items:center;">
          ${e({label:"Large",style:"plus",size:"large",state:"default",open:!1})}
          ${e({label:"Medium",style:"plus",size:"medium",state:"default",open:!1})}
          ${e({label:"Small",style:"plus",size:"small",state:"default",open:!1})}
        </div>
        <span style="font-size:11px;color:#8D9091;">PLUS STYLE — Open</span>
        <div style="display:flex;gap:24px;align-items:center;">
          ${e({label:"Large",style:"plus",size:"large",state:"default",open:!0})}
          ${e({label:"Medium",style:"plus",size:"medium",state:"default",open:!0})}
          ${e({label:"Small",style:"plus",size:"small",state:"default",open:!0})}
        </div>
        <span style="font-size:11px;color:#8D9091;">PLUS STYLE — Hover</span>
        <div style="display:flex;gap:24px;align-items:center;">
          ${e({label:"Closed",style:"plus",size:"medium",state:"hover",open:!1})}
          ${e({label:"Open",style:"plus",size:"medium",state:"hover",open:!0})}
        </div>
      </div>

    </div>
  `},H=["CaretClosedDefault","CaretOpenDefault","CaretClosedHover","CaretOpenHover","PlusClosedDefault","PlusOpenDefault","PlusClosedHover","PlusOpenHover","Large","Small","AllVariants"];export{w as AllVariants,z as CaretClosedDefault,k as CaretClosedHover,C as CaretOpenDefault,$ as CaretOpenHover,P as Large,L as PlusClosedDefault,S as PlusClosedHover,_ as PlusOpenDefault,O as PlusOpenHover,D as Small,H as __namedExportsOrder,b as default};
