const i=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;600&display=swap');
    :root {
      --color-label: #4D586A;
      --color-optional: #8D9091;
      --color-placeholder: #8D9091;
      --color-text: #4D586A;
      --color-error: #CA222D;
      --color-border-default: #CCCCCC;
      --color-border-focus: #007CBD;
      --color-border-error: #CA222D;
      --color-bg-white: #FFFFFF;
      --font-family: 'Figtree', sans-serif;
      --border-radius-sm: 4px;
    }

    .rais-datepicker { display:flex; flex-direction:column; gap:4px; width:350px; font-family:var(--font-family); }
    .rais-datepicker__labels { display:flex; flex-direction:column; gap:2px; }
    .rais-datepicker__label-row { display:flex; flex-direction:row; align-items:flex-start; gap:12px; }
    .rais-datepicker__label { font-size:14px; font-weight:600; color:var(--color-label); line-height:1.2; }
    .rais-datepicker__optional { font-size:14px; color:var(--color-optional); line-height:1.2; }
    .rais-datepicker__instructions { font-size:12px; color:var(--color-label); line-height:1.2; }

    /* Input box: 350x40, padding T8 R16 B8 L16, gap 16 */
    .rais-datepicker__box {
      display:flex; flex-direction:row; align-items:center;
      height:40px; padding:8px 16px;
      background:var(--color-bg-white);
      border:1px solid var(--color-border-default);
      border-radius:var(--border-radius-sm);
      box-sizing:border-box; gap:16px;
    }
    .rais-datepicker__box--focus { border-color:var(--color-border-focus); }
    .rais-datepicker__box--error { border-color:var(--color-border-error); }

    .rais-datepicker__date-container { display:flex; flex-direction:row; align-items:center; gap:4px; flex:1; min-width:0; }
    .rais-datepicker__date { font-size:14px; color:var(--color-text); line-height:1; }
    .rais-datepicker__placeholder { font-size:14px; color:var(--color-placeholder); line-height:1; }

    /* Calendar icon: 16x16, bxs-calendar.svg */
    .rais-datepicker__icon { width:16px; height:16px; display:flex; align-items:center; justify-content:center; flex-shrink:0; }

    /* Icon tints */
    .rais-datepicker__icon--default img { filter: brightness(0) saturate(100%) invert(29%) sepia(5%) saturate(580%) hue-rotate(169deg); }
    .rais-datepicker__icon--focus   img { filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg); }
    .rais-datepicker__icon--error   img { filter: invert(30%) sepia(10%) saturate(800%) hue-rotate(180deg); }

    .rais-datepicker__error { font-size:12px; color:var(--color-error); line-height:1.2; }
  </style>
`;function e({label:a,optional:s,instructions:l,state:r,value:c,errorMessage:n}){const d=!r||r==="empty",o=r==="error",t=r==="focus",p=["rais-datepicker__box",t?"rais-datepicker__box--focus":"",o?"rais-datepicker__box--error":""].filter(Boolean).join(" "),u=o?"rais-datepicker__icon--error":t?"rais-datepicker__icon--focus":"rais-datepicker__icon--default",_=d?'<span class="rais-datepicker__placeholder">MM/DD/YYYY</span>':`<span class="rais-datepicker__date">${c??"12/21/2024"}</span>`;return`
    ${i}
    <div class="rais-datepicker">
      <div class="rais-datepicker__labels">
        <div class="rais-datepicker__label-row">
          <span class="rais-datepicker__label">${a??"Label"}</span>
          ${s?'<span class="rais-datepicker__optional">(Optional)</span>':""}
        </div>
        ${l!==!1?'<span class="rais-datepicker__instructions">More instructions here.</span>':""}
      </div>
      <div class="${p}">
        <div class="rais-datepicker__date-container">${_}</div>
        <div class="rais-datepicker__icon ${u}">
          <img src="assets/boxicons/bxs-calendar.svg" width="16" height="16" alt="calendar" />
        </div>
      </div>
      ${o?`<span class="rais-datepicker__error">${n??"Error message."}</span>`:""}
    </div>
  `}const x={title:"RAIS/Inputs/Fields/Date Picker",tags:["autodocs"],argTypes:{label:{control:"text"},optional:{control:"boolean"},instructions:{control:"boolean"},value:{control:"text",description:"MM/DD/YYYY format"},state:{control:"select",options:["empty","filled","focus","error"]},errorMessage:{control:"text"}},render:a=>e(a)},b={args:{label:"Label",state:"empty",instructions:!0}},f={args:{label:"Label",state:"filled",value:"12/21/2024",instructions:!0}},g={args:{label:"Label",state:"focus",value:"12/21/2024",instructions:!0}},k={args:{label:"Label",state:"error",value:"12/21/2024",instructions:!0,errorMessage:"Error message."}},v={args:{label:"Label",optional:!0,state:"empty",instructions:!0}},h={render:()=>`
    ${i}
    <div style="display:flex;flex-direction:column;gap:24px;padding:24px;background:#F0F2F5;border-radius:8px;">
      ${e({label:"Empty",state:"empty",instructions:!0})}
      ${e({label:"Filled",state:"filled",value:"12/21/2024",instructions:!0})}
      ${e({label:"On Focus",state:"focus",value:"12/21/2024",instructions:!0})}
      ${e({label:"Error",state:"error",value:"12/21/2024",instructions:!0,errorMessage:"Error message."})}
    </div>
  `},m=["Empty","Filled","OnFocus","Error","Optional","AllVariants"];export{h as AllVariants,b as Empty,k as Error,f as Filled,g as OnFocus,v as Optional,m as __namedExportsOrder,x as default};
