const b=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;600&display=swap');
    :root {
      --color-btn-bg-primary:          #007CBD;
      --color-btn-bg-primary-hover:    #178FCF;
      --color-btn-bg-primary-disabled: #B3D8EB;
      --color-btn-text-primary:        #FFFFFF;
      --color-btn-bg-secondary:        #FFFFFF;
      --color-btn-bg-secondary-hover:  #EDF6FC;
      --color-btn-border-secondary:    #007CBD;
      --color-btn-text-secondary:      #007CBD;
      --color-btn-bg-error:            #CA222D;
      --color-btn-text-error:          #CA222D;
      --font-family: 'Figtree', sans-serif;
      --font-weight-semibold: 600;
      --border-radius-sm: 4px;
    }

    .rais-btn {
      font-family: var(--font-family);
      font-weight: var(--font-weight-semibold);
      border-radius: var(--border-radius-sm);
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      border: 1px solid transparent;
      transition: background 0.15s ease, color 0.15s ease;
      line-height: 1;
    }
    .rais-btn--normal { padding: 8px 16px;  font-size: 14px; }
    .rais-btn--small  { padding: 4px 10px;  font-size: 12px; }
    .rais-btn--large  { padding: 12px 24px; font-size: 16px; }

    .rais-btn--primary {
      background: var(--color-btn-bg-primary);
      color: var(--color-btn-text-primary);
      border-color: var(--color-btn-bg-primary);
    }
    .rais-btn--primary:hover {
      background: var(--color-btn-bg-primary-hover);
      border-color: var(--color-btn-bg-primary-hover);
    }
    .rais-btn--secondary {
      background: var(--color-btn-bg-secondary);
      color: var(--color-btn-text-secondary);
      border-color: var(--color-btn-border-secondary);
    }
    .rais-btn--secondary:hover { background: var(--color-btn-bg-secondary-hover); }
    .rais-btn--danger {
      background: var(--color-btn-bg-secondary);
      color: var(--color-btn-text-error);
      border-color: var(--color-btn-bg-error);
    }
    .rais-btn--disabled {
      background: var(--color-btn-bg-primary-disabled);
      color: var(--color-btn-text-primary);
      border-color: var(--color-btn-bg-primary-disabled);
      cursor: not-allowed;
      opacity: 0.7;
    }

    .rais-btn img { display: block; flex-shrink: 0; }
    /* Icon sizes per button size */
    .rais-btn--normal img { width: 16px; height: 16px; }
    .rais-btn--small  img { width: 14px; height: 14px; }
    .rais-btn--large  img { width: 18px; height: 18px; }

    /* Invert icon color for primary/disabled buttons (white bg needed) */
    .rais-btn--primary img,
    .rais-btn--disabled img { filter: brightness(0) invert(1); }
  </style>
`,p=["","bx-download","bx-upload","bx-plus","bx-minus","bx-trash","bx-edit","bx-save","bx-search","bx-filter","bx-refresh","bx-check","bx-x","bx-right-arrow-alt","bx-left-arrow-alt","bx-export","bx-import","bx-copy","bx-print","bx-share-alt","bx-link-external","bxs-save","bxs-download","bxs-edit","bxs-trash","bxs-plus-circle","bxs-check-circle"];function m(r,a="normal"){if(!r)return"";const t=a==="small"?14:a==="large"?18:16;return`<img src="assets/boxicons/${r}.svg" width="${t}" height="${t}" alt="${r}" />`}function o({label:r,variant:a,size:t,icon:n,iconPos:c}){const e=t??"normal",s=a??"primary",d=`rais-btn rais-btn--${s} rais-btn--${e}`,g=s==="disabled",l=n?m(n,e):"";let i="";return n&&c==="right"?i=`${r??"Button"}${l}`:n?i=`${l}${r??"Button"}`:i=r??"Button",`
    ${b}
    <button class="${d}" ${g?"disabled":""}>
      ${i}
    </button>
  `}const x={title:"RAIS/Actions/Button",tags:["autodocs"],argTypes:{label:{control:"text",description:"Button label text"},variant:{control:"select",options:["primary","secondary","danger","disabled"],description:"Visual style variant"},size:{control:"select",options:["small","normal","large"],description:"Button size"},icon:{control:"select",options:p,description:'Boxicons SVG from public/assets/boxicons/ — Angular: <img src="assets/boxicons/[name].svg" />'},iconPos:{control:"select",options:["left","right"],description:"Icon position"}},render:r=>o(r)},y={args:{label:"Submit",variant:"primary",size:"normal",icon:"",iconPos:"left"}},v={args:{label:"Cancel",variant:"secondary",size:"normal",icon:"",iconPos:"left"}},h={args:{label:"Delete",variant:"danger",size:"normal",icon:"",iconPos:"left"}},f={args:{label:"Unavailable",variant:"disabled",size:"normal",icon:"",iconPos:"left"}},u={args:{label:"Small",variant:"primary",size:"small",icon:"",iconPos:"left"}},w={args:{label:"Large",variant:"primary",size:"large",icon:"",iconPos:"left"}},$={args:{label:"Download",variant:"primary",size:"normal",icon:"bx-download",iconPos:"left"}},z={args:{label:"Next",variant:"primary",size:"normal",icon:"bx-right-arrow-alt",iconPos:"right"}},F={render:()=>`
    ${b}
    <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:center;padding:24px;background:#F0F2F5;border-radius:8px;">
      ${o({label:"Primary",variant:"primary",size:"normal"})}
      ${o({label:"Secondary",variant:"secondary",size:"normal"})}
      ${o({label:"Danger",variant:"danger",size:"normal"})}
      ${o({label:"Disabled",variant:"disabled",size:"normal"})}
      ${o({label:"Small",variant:"primary",size:"small"})}
      ${o({label:"Large",variant:"primary",size:"large"})}
      ${o({label:"Download",variant:"primary",size:"normal",icon:"bx-download",iconPos:"left"})}
      ${o({label:"Next",variant:"primary",size:"normal",icon:"bx-right-arrow-alt",iconPos:"right"})}
    </div>
  `},D=["Primary","Secondary","Danger","Disabled","Small","Large","WithIconLeft","WithIconRight","AllVariants"];export{F as AllVariants,h as Danger,f as Disabled,w as Large,y as Primary,v as Secondary,u as Small,$ as WithIconLeft,z as WithIconRight,D as __namedExportsOrder,x as default};
