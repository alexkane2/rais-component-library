const n=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;600&display=swap');
    :root {
      --color-label: #4D586A;
      --color-optional: #8D9091;
      --color-placeholder: #CCCCCC;
      --color-text: #4D586A;
      --color-option-name: #333333;
      --color-option-detail: #606060;
      --color-error: #CA222D;
      --color-divider: #EFEFEF;
      --color-border-default: #CCCCCC;
      --color-border-focus: #007CBD;
      --color-border-error: #CA222D;
      --color-bg-white: #FFFFFF;
      --color-bg-hover: #EDF6FC;
      --font-family: 'Figtree', sans-serif;
      --border-radius-sm: 4px;
    }

    .rais-search { display:flex; flex-direction:column; gap:4px; width:350px; font-family:var(--font-family); position:relative; }
    .rais-search__labels { display:flex; flex-direction:column; gap:2px; }
    .rais-search__label-row { display:flex; align-items:center; gap:4px; }
    .rais-search__label { font-size:14px; font-weight:600; color:var(--color-label); }
    .rais-search__optional { font-size:14px; color:var(--color-optional); }
    .rais-search__instructions { font-size:12px; color:var(--color-label); }

    .rais-search__box {
      display:flex; align-items:center; justify-content:space-between;
      height:40px; padding:8px 12px;
      background:var(--color-bg-white);
      border:1px solid var(--color-border-default);
      border-radius:var(--border-radius-sm);
      box-sizing:border-box; gap:8px;
    }
    .rais-search__box--active { border-color:var(--color-border-focus); }
    .rais-search__box--error  { border-color:var(--color-border-error); }

    .rais-search__input-container { flex:1; min-width:0; display:flex; align-items:center; }
    .rais-search__input {
      width:100%; border:none; outline:none;
      font-family:var(--font-family); font-size:14px;
      color:var(--color-text); background:transparent;
    }
    .rais-search__input::placeholder { color:var(--color-placeholder); }

    /* Icon and Divider: 1x24 divider + icon, gap 10 */
    .rais-search__icon-divider { display:flex; align-items:center; gap:10px; flex-shrink:0; }
    .rais-search__divider { width:1px; height:24px; background:var(--color-divider); flex-shrink:0; }
    .rais-search__icon { width:20px; height:20px; display:flex; align-items:center; justify-content:center; flex-shrink:0; cursor:pointer; }

    .rais-search__menu {
      position:absolute; top:calc(100% + 2px); left:0; right:0;
      background:var(--color-bg-white);
      border:1px solid var(--color-border-default);
      border-radius:var(--border-radius-sm);
      box-shadow:0 4px 10px rgba(0,0,0,0.08);
      z-index:10; max-height:260px; overflow-y:auto;
    }
    .rais-search__option { padding:10px 12px; cursor:pointer; }
    .rais-search__option:hover { background:var(--color-bg-hover); }
    .rais-search__option-name { font-size:14px; font-weight:600; color:var(--color-option-name); }
    .rais-search__option-detail { font-size:14px; color:var(--color-option-detail); margin-top:2px; }
    .rais-search__error { font-size:12px; color:var(--color-error); }
  </style>
`,b=[{name:"128 Plumbing Heating Inc",detail:"78 Foundry Street, Wakefield, MA 01880"},{name:"3D Plumbing Heating Inc",detail:"140 Grove St Apt 1, Clinton, MA 01510"},{name:"4 H Plumbing Inc",detail:""},{name:"A Advantage Plumbing",detail:"34625 Cedar Avenue, Yucaipa, CA 92399"},{name:"A Plus Plumbing LLC",detail:"25 Sycamore Avenue, Gustine, CA 92794"}];function r({label:a,optional:c,instructions:d,state:o}){const s=o==="error",e=o==="active",t=o==="selection",p=["rais-search__box",s?"rais-search__box--error":"",e?"rais-search__box--active":""].filter(Boolean).join(" "),u=e?"plum":t?"3D Plumbing Heating Inc":"",l=t||e?"bx-x":"bx-caret-down";return`
    ${n}
    <div class="rais-search">
      <div class="rais-search__labels">
        <div class="rais-search__label-row">
          <span class="rais-search__label">${a??"Label"}</span>
          ${c?'<span class="rais-search__optional">(Optional)</span>':""}
        </div>
        ${d!==!1?'<span class="rais-search__instructions">More instructions here.</span>':""}
      </div>
      <div class="${p}">
        <div class="rais-search__input-container">
          <input class="rais-search__input" type="text" placeholder="Type name..." value="${u}" />
        </div>
        <div class="rais-search__icon-divider">
          <div class="rais-search__divider"></div>
          <div class="rais-search__icon">
            <img src="assets/boxicons/${l}.svg" width="16" height="16" alt="${l}" />
          </div>
        </div>
      </div>
      ${e?`
        <div class="rais-search__menu">
          ${b.map(i=>`
            <div class="rais-search__option">
              <div class="rais-search__option-name">${i.name}</div>
              ${i.detail?`<div class="rais-search__option-detail">${i.detail}</div>`:""}
            </div>
          `).join("")}
        </div>
      `:""}
      ${s?'<span class="rais-search__error">Error message.</span>':""}
    </div>
  `}const h={title:"RAIS/Inputs/Dropdowns/Dropdown - Searchable",tags:["autodocs"],argTypes:{label:{control:"text"},optional:{control:"boolean"},instructions:{control:"boolean"},state:{control:"select",options:["default","selection","active","error"]}},render:a=>r(a)},_={args:{label:"Label",state:"default",instructions:!0}},v={args:{label:"Label",state:"selection",instructions:!0}},x={args:{label:"Label",state:"active",instructions:!0}},g={args:{label:"Label",state:"error",instructions:!0}},f={args:{label:"Label",optional:!0,state:"default",instructions:!0}},m={render:()=>`
    ${n}
    <div style="display:flex;flex-direction:column;gap:80px;padding:24px;background:#F0F2F5;border-radius:8px;">
      ${r({label:"Default",state:"default",instructions:!0})}
      ${r({label:"Selection",state:"selection",instructions:!0})}
      ${r({label:"Active / Searching",state:"active",instructions:!0})}
      ${r({label:"Error",state:"error",instructions:!0})}
    </div>
  `},y=["Default","Selection","Active","Error","Optional","AllVariants"];export{x as Active,m as AllVariants,_ as Default,g as Error,f as Optional,v as Selection,y as __namedExportsOrder,h as default};
