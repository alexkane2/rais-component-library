const t=`
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Figtree:wght@400;700&display=swap');

    /* Tokens — names match Figma variables */
    :root {
      --surface-hover: #EDF6FC;
      --brand-blue-200: #007CBD;
      --border-focus: #007CBD;
      --spacing-01: 4px;
      --chip-text: #101928;
      --font-family: 'Figtree', sans-serif;
    }

    /* ── Applied Filter Chip ──
       padding: T4 R10 B4 L6, gap 8
       bg --surface-hover, border --brand-blue-200 1px, radius --spacing-01
       HORIZONTAL, crossAxis CENTER
    ── */
    .rais-filter-chip {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      padding: 4px 10px 4px 6px;
      background: var(--surface-hover);
      border: 1px solid var(--brand-blue-200);
      border-radius: var(--spacing-01);
      font-family: var(--font-family);
      max-width: 250px;
      box-sizing: border-box;
      height: 22px;
    }

    /* Must have chips have no dismiss — tighten right padding */
    .rais-filter-chip--must-have {
      padding-right: 8px;
    }

    /* ── Filter icon: 14×14 frame, bxs-filter-alt ── */
    .rais-filter-chip__filter-icon {
      width: 14px;
      height: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
    }

    /* Tint filter icon to --brand-blue-200 */
    .rais-filter-chip__filter-icon img {
      filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg);
    }

    /* ── Text area: category (bold) + value (regular) ── */
    .rais-filter-chip__text {
      display: flex;
      align-items: center;
      gap: 4px;
      min-width: 0;
      overflow: hidden;
    }

    .rais-filter-chip__category {
      font-size: 12px;
      font-weight: 700;
      color: var(--chip-text);
      white-space: nowrap;
      flex-shrink: 0;
    }

    .rais-filter-chip__value {
      font-size: 12px;
      font-weight: 400;
      color: var(--chip-text);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* ── Dismiss icon: 12×12 to match Figma vector size (NOT 8×8 frame) ── */
    .rais-filter-chip__dismiss {
      width: 12px;
      height: 12px;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-shrink: 0;
      cursor: pointer;
    }

    /* Tint dismiss icon to --brand-blue-200 */
    .rais-filter-chip__dismiss img {
      width: 12px;
      height: 12px;
      filter: invert(35%) sepia(87%) saturate(500%) hue-rotate(170deg);
    }
  </style>
`;function e({category:i,value:a,showIcon:r,dismissible:l}){const o=i??"Category:",n=a??"Filter",c=r??!1,s=l!==!1,p=["rais-filter-chip",s?"":"rais-filter-chip--must-have"].filter(Boolean).join(" ");return`
    ${t}
    <span class="${p}">
      ${c?`
        <span class="rais-filter-chip__filter-icon">
          <img src="assets/boxicons/bxs-filter-alt.svg" width="14" height="14" alt="filter" />
        </span>
      `:""}
      <span class="rais-filter-chip__text">
        <span class="rais-filter-chip__category">${o}</span>
        <span class="rais-filter-chip__value">${n}</span>
      </span>
      ${s?`
        <span class="rais-filter-chip__dismiss">
          <img src="assets/boxicons/bx-x.svg" width="12" height="12" alt="dismiss" />
        </span>
      `:""}
    </span>
  `}const d={title:"RAIS/Filters/Applied Filter Chip",tags:["autodocs"],argTypes:{category:{control:"text",description:"Category label (bold text before the value)"},value:{control:"text",description:"Filter value text"},showIcon:{control:"boolean",description:"Show filter icon (bxs-filter-alt.svg) on the left"},dismissible:{control:"boolean",description:'Show dismiss X (bx-x.svg) on the right — false for "must have" filters'}},render:i=>e(i)},f={args:{category:"Policy Producer:",value:"Spencer, Dana",showIcon:!1,dismissible:!0}},g={args:{category:"Policy Producer:",value:"Multiple",showIcon:!1,dismissible:!0}},h={args:{category:"Policy Producer:",value:"Very Long Filter Lab...",showIcon:!1,dismissible:!0}},u={name:"Must Have (no dismiss)",args:{category:"Region:",value:"West",showIcon:!1,dismissible:!1}},x={args:{category:"Category:",value:"Filter",showIcon:!0,dismissible:!0}},m={name:"Must Have + Icon",args:{category:"Category:",value:"Filter",showIcon:!0,dismissible:!1}},v={render:()=>`
    ${t}
    <div style="display:flex;flex-direction:column;gap:16px;padding:24px;background:#F0F2F5;border-radius:8px;">
      <span style="font-family:'Figtree',sans-serif;font-size:11px;color:#8D9091;">DISMISSIBLE</span>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
        ${e({category:"Policy Producer:",value:"Spencer, Dana",showIcon:!1,dismissible:!0})}
        ${e({category:"Policy Producer:",value:"Multiple",showIcon:!1,dismissible:!0})}
        ${e({category:"Policy Producer:",value:"Very Long Filter Lab...",showIcon:!1,dismissible:!0})}
      </div>

      <span style="font-family:'Figtree',sans-serif;font-size:11px;color:#8D9091;">MUST HAVE (no dismiss)</span>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
        ${e({category:"Region:",value:"West",showIcon:!1,dismissible:!1})}
        ${e({category:"Status:",value:"Active",showIcon:!1,dismissible:!1})}
      </div>

      <span style="font-family:'Figtree',sans-serif;font-size:11px;color:#8D9091;">WITH FILTER ICON</span>
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
        ${e({category:"Category:",value:"Filter",showIcon:!0,dismissible:!0})}
        ${e({category:"Category:",value:"Filter",showIcon:!0,dismissible:!1})}
      </div>
    </div>
  `},y=["SingleSelection","MultipleSelections","Truncated","MustHave","WithIcon","MustHaveWithIcon","AllVariants"];export{v as AllVariants,g as MultipleSelections,u as MustHave,m as MustHaveWithIcon,f as SingleSelection,h as Truncated,x as WithIcon,y as __namedExportsOrder,d as default};
